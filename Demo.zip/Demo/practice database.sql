create database Practice_Initiative_Management;
use Practice_Initiative_Management;

create table employee(
employee_id int auto_increment not null primary key,
employee_name varchar(45) not null,
employee_email varchar(100) not null,
employee_skills varchar(100) not null,
employee_designation varchar(100) not null,
proj_id int,
constraint FK_employee1 foreign key (proj_id)
references project(proj_id)
);

drop table employee;
show tables;

insert into employee(employee_name,employee_email,employee_skills,employee_designation)
values ("Jennifer Henry","jennhenry@gmail.com","React,Mysql,Excel","Assistant Manager"),
("Ivan Guerra","ivangurra@gmail.com","Python,sql,react","Assistant Manager"),
("Renee Santiago","rennesantiago@gmail.com","Java,Python,react,excel","Assistant Manager"),
("Joe Evans","joeevans@gmail.com",",Java,excel,mysql","Analyst"),
("Maryjane Carr","maryjane@gmail.com","Python,php,html","Analyst"),
("Devon Rowe","devon@gmail.com","Python,Vuejs,flask","Consultant"),
("Rogelio Mcgrath","rogelio@gmail.com","Java,RPA developer,flask","Consultant"),
("Cindy Adams","cindyadams@gmail.com","Python,React,mongodb","Consultant"),
("Kianna Peterson","kianna@gmail.com","Python,React,Mysql","Associate Consultant"),
("Kinley Fernandez","kinley@gmail.com","JSP,Agile,Mysql","Associate Consultant"),
("Johan Collier","colliar@gmail.com","XML,Docker,Hibernet","Associate Consultant"),
("Cade Manning","cademan@gmail.com","PowerBI,Advanced excel,machine learning","Manager"),
("Cael Brock","caelbrock@gmail.com","PowerBI,Advanced RPA,machine learning & AI","Manager"),
("Manuel Martin","manuel@gmail.com","Project Management,machine learning & AI","Manager"),
("Lamar Dean","lamardean@gmail.com","Project Management,kafka,Power BI","Associate Director"),
("Zoie Lindsey","zoielind@gmail.com","Project Management,kafka,Kubernates","Associate Director"),
("Zoie Lindsey","zoielind@gmail.com","Project Management,kafka,Kubernates","Associate Director"),
("Elvis York","elvis@gmail.com","Project Management,oracle,azure,SDLC","Director"),
("Alan Mahoney","alanmah@gmail.com","Project Management,oracle,azure,Big Data","Director");

select * from employee;

create table project(
proj_id int not null primary key auto_increment,
proj_name varchar(100) not null,
client_name varchar(100) not null,
proj_start date,
proj_end date not null,
proj_status varchar(100) not null,
proj_skills varchar(100) not null,
bugs_open int not null,
bugs_closed int not null
);

drop table project;
alter table project auto_increment=1000;
desc project;

insert into project(proj_name,client_name,proj_start,proj_end,proj_status,proj_skills,bugs_open,bugs_closed)
values("bank_icici","ICICI Bank","2021-09-05","2022-02-11","Ongoing","Mysql,excel,java,React,Project Management",2,6),
("bank_hdfc","HDFC Bank","2021-10-17","2022-03-30","Ongoing","Mysql,python,flask,Vuejs,Project Management",4,10),
("bank_canara","CANARA Bank","2021-11-14","2022-04-28","Ongoing","Project Management,oracle,Java",10,3),
("bank_anz","ANZ Bank","2021-08-15","2022-02-15","Ongoing","Project Management,mongodb,XML,RPA",6,4),
("bank_BOB","Bank of Baroda","2021-07-10","2021-12-23","Ongoing","Project Management,Power BI,Python,Agile",2,5),
("bank_PNB","Punjab National Bank","2021-06-15","2021-10-15","Completed","Project Management,azure,php,java,python",0,10),
("bank_sbi","SBI Bank","2021-05-01","2021-11-19","Completed","Project Management,Machine Learning & AI,Big Data,mysql,RPA",0,15);

select * from project;

create table pipeline1(
pipe_id int not null primary key,
pipe_name varchar(100) not null,
clientname varchar(100) not null,
pipe_start date not null,
pipedur varchar(100) not null,
pipe_skills varchar(100) not null
);

create table bank_icici(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key(bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int 
);

insert into bank_icici set proj_name = 'bank_icici',proj_start = '2021-09-05',proj_end='2022-02-11',
proj_status = 'Ongoing',bugs_open=2, bugs_closed=6,
bank_proj_id = (
select proj_id from project where proj_id = 1000);

select * from bank_icici;


create table bank_hdfc(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_hdfc set proj_name ='bank_hdfc',proj_start ='2021-10-17',proj_end='2022-03-30',
proj_status ='Ongoing',bugs_open=4, bugs_closed=10,
bank_proj_id = (
select proj_id from project where proj_id = 1001);

select * from bank_hdfc;

create table bank_canara(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_canara set proj_name ='bank_canara',proj_start ='2021-11-14',proj_end='2022-04-28',
proj_status ='Ongoing',bugs_open=10, bugs_closed=3,
bank_proj_id = (
select proj_id from project where proj_id = 1002);

select * from bank_canara;
delete from bank_canara where bank_proj_id = 1002;

create table bank_anz(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_anz set proj_name ='bank_anz',proj_start ='2021-08-15',proj_end='2022-02-15',
proj_status ='Ongoing',bugs_open=6, bugs_closed=4,
bank_proj_id = (
select proj_id from project where proj_id = 1003);

create table bank_bob(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_bob set proj_name ='bank_BOB',proj_start ='2021-07-10',proj_end='2021-12-23',
proj_status ='Ongoing',bugs_open=2, bugs_closed=5,
bank_proj_id = (
select proj_id from project where proj_id = 1004);

select * from bank_bob;

create table bank_pnb(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_pnb set proj_name ='bank_PNB',proj_start ='2021-06-15',proj_end='2021-10-15',
proj_status ='Completed',bugs_open=0, bugs_closed=10,
bank_proj_id = (
select proj_id from project where proj_id = 1005);

select * from bank_pnb;

create table bank_sbi(
bank_proj_id int,
proj_name varchar(100),
proj_start date,
proj_end date,
proj_status varchar(100),
index (bank_proj_id), foreign key (bank_proj_id) 
references project(proj_id),
bugs_open int,
bugs_closed int
);

insert into bank_sbi set proj_name ='bank_sbi',proj_start ='2021-05-01',proj_end='2021-11-19',
proj_status ='Completed',bugs_open=0, bugs_closed=15,
bank_proj_id = (
select proj_id from project where proj_id = 1006);

select * from bank_sbi;








